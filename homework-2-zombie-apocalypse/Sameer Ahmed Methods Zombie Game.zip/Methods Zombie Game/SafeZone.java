public class SafeZone {
    private static int x = 400;
    private static int width = 80;
    private static int y = 445;

    public static void draw() {
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.filledRectangle(x, 580, 20, 25);
    }
    public static boolean isTouching(){
        boolean isTouching;
        if(Player.getX() == x && Player.getY() == y){
            isTouching = true;
        }
        else{
            isTouching = false;
        }
        return isTouching;
    }
}