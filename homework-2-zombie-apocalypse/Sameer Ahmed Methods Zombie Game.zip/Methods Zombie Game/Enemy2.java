import java.awt.Rectangle;
public class Enemy2 {
    private static String image;
    private static int width;
    private static int height;
    private static int x;
    private static int y;
    private static long time;

    public static void draw() {
        StdDraw.picture(x + width / 2, y + height / 2, image);
    }

    public static void start() {
        image = "assets/zombie.gif";
        width = 81;
        height = 96;
        x = (int)(Math.random() * 700);
        y = (int)(Math.random() * 445);
        time = System.currentTimeMillis();
    }

    public static void move() {
        x = (int)(Math.random() * 700);
        y = (int)(Math.random() * 445);
        time = System.currentTimeMillis();
    }

    public static void update() {
        long now = System.currentTimeMillis();
        if (now - time > 1500) {
            Enemy2.move();
        }
        Enemy2.topLimit();
        Enemy2.bottomLimit();
        Enemy2.leftLimit();
        Enemy2.rightLimit();
    }

    public static void topLimit() {
        if (y == -65) {
            y = -55;
        }
    }

    public static void bottomLimit() {
        if (y == 455) {
            y = 445;
        }
    }

    public static void leftLimit() {
        if (x == 0) {
            x = 10;
        }
    }

    public static void rightLimit() {
        if (x == 710) {
            x = 700;
        }
    }
    public static int getX(){
        return x;
    }
    public static int getY(){
        return y;
    }
    public static boolean isTouching(){
        Rectangle enemyBox = new Rectangle(Enemy2.x,Enemy2.y,43,43);
        Rectangle playerBox = new Rectangle(Player.getX(),Player.getY(),43,43);
        boolean isTouching;

        if(playerBox.intersects(enemyBox)){
            isTouching = true;
        }
        else{
            isTouching = false;
        }
        return isTouching;
    }
}
