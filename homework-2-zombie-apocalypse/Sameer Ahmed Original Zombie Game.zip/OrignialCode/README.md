# Homework 2 Zombie Apocalypse
Author: Sameer Ahmed

Summary of code: 
The code is a basic one level zombie apocalypse game
that to win you have to keep an eye of your food level so that you don't die of
hunger. The other win condition is that you have to find the key on the map before
entering the safe zone. 
The way you would end up losing the game is by either getting touched by the zombies
on the map moving randomly or by falling into the flaming traps.

The player moves on the play field when either w, a, s, or d key is pressed.
You cannot type multiple keys in at once you would have to press the keys to
move in your desired direction one at a time.

Features added onto the base game are listed below:
    Colored Play Field
    Customized skins(emojis) set for the player, zombies, food, key, safezone, 
    and traps.
    Added a food counter that starts off with 10 food and when it hits zero it ends the 
    game and to not lose of hunger two different food types with different saturation 
    levels were added that the player should go for first in the gameplay.
    Added in a key that allows the player to win if they aquire it and get to the 
    safezone. Winning is not possible without the key.
    Added more zombies on top of the one we started off with all of them move randomly
    on the play field.
    Made it so that the player can't go off of the play area and they get a message if 
    they try to.
    Multiple traps were also added onto the play field that have the fire emoji that 
    instantly end the game if touched.

The way to play my version of the game is to keep an eye on the food bar so that you 
don't die of hunger. The way to gewt rid of that problem would be to move the players towards
the two different types of foods on the map. There are two canned food on the map that 
spawn randomly that give back 5 points of hunger and the next type is the meal that gives back
10 points of hunger but, there is only one on the map.

Besides hunger the way to actually win the game comes down to if you have the key before getting
to the safezone. Once you get to the safe zone if you do not have the key the game won't end alternately
it'll post a message telling the player to find the key first. Once the player has the key they'll be able 
to go to the safezone and end the game.

Ways to lose in the game are the food bar hitting zero as explained above and two other ways. The other ways 
to lose the game would be to move into a play tile that has the fire emoji that counts as a trap and instantly 
ends the game. The other instant game over is by getting touched by one of the three zombies.

