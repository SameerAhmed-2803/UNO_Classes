# hw3-methods
This contains the starter files needed for homework 3: methods.
- StdDraw is a java library for drawing graphics
- assets is a folder containing art assets for thus project